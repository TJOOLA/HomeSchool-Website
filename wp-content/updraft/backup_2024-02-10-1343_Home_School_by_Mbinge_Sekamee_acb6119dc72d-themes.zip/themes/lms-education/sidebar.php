<div class="sidebar-area mt-5">
  <?php
    dynamic_sidebar('lms-education-sidebar');
  ?>
</div>